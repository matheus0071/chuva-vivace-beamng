local M = {type='auxiliary',defaultOrder=80}
local model=require('vrRainModel')
local puddleModel=require('vrPuddles')
local pools={}
local affected={}
local physicsTimer=0
local asphaltTimer=0
local state=model.new()
local drops={}
local rain=0
local mode=0
local function setRain(value)
  value=tonumber(value) or 0
  if value~=value then value=0 end
  rain=math.max(0,math.min(1,value))
end
local function setMode(value)
  model.setMode(state,value)
  mode=state.mode
end
local function cycle() setMode((mode+1)%4) end
local function setPuddles(value) pools=type(value)=="table" and value or {} end
local function reset()
  state=model.new();model.setMode(state,mode)
  drops={}
  affected={}
  physicsTimer=0
  asphaltTimer=0
  for _,prop in pairs(v.data.props or {}) do
    local index=prop.vrDropIndex
    if index then
      local source={angles={prop.vrAngle1 or -10,prop.vrAngle2 or -10},threshold=prop.vrDropDelay or 1}
      if source then
        local angle=source.angles[1]>=0 and source.angles[1] or source.angles[2]
        drops[#drops+1]={prop=prop,angle=angle,angles=source.angles,covered=angle>=0,visible=false,age=0,threshold=source.threshold}
        prop.hidden=true
      end
    end
  end
  electrics.values.vr_wiper=0
  obj:queueGameEngineLua('local o=be:getObjectByID('..obj:getID()..'); if o then o:setMeshAlpha(0,"vivace_wipers_F",false) end; if not extensions.vrRain then extensions.load("vrRain") end; if extensions.vrRain then extensions.vrRain.setRain(0.8); extensions.vrRain.syncVehicle('..obj:getID()..') end')
end
local function updatePuddleGrip(dt)
  physicsTimer=physicsTimer+dt
  if physicsTimer<.04 then return end
  physicsTimer=0
  if not wheels or not wheels.wheels then return end
  local origin=obj:getPosition()
  local speed=electrics.values.airspeed or electrics.values.wheelspeed or 0
  asphaltTimer=asphaltTimer+.04
  local reportAsphalt=asphaltTimer>=.45
  if reportAsphalt then asphaltTimer=0 end
  for _,wheel in pairs(wheels.wheels) do
    local material=wheel.contactMaterialID1
    if not puddleModel.isAsphalt(material) then material=wheel.contactMaterialID2 end
    if reportAsphalt and rain>0 and puddleModel.isAsphalt(material) and not wheel.isBroken and not wheel.isTireDeflated then
      local contact
      for _,nodeId in pairs(wheel.treadNodes or {}) do
        local q=obj:getNodePosition(nodeId)+origin
        if not contact or q.z<contact.z then contact=q end
      end
      if contact then
        obj:queueGameEngineLua(string.format('if extensions.vrRain then extensions.vrRain.recordAsphaltContact(%d,%.3f,%.3f,%.3f) end',material,contact.x,contact.y,contact.z))
      end
    end
    local factor=1
    if rain>0 and #pools>0 and not wheel.isBroken and not wheel.isTireDeflated then
      local p=obj:getNodePosition(wheel.node1)+origin
      factor=puddleModel.grip(pools,p.x,p.y,p.z,speed,rain)
    end
    for _,cid in pairs(wheel.treadNodes or {}) do
      if not wheel.isBroken and not wheel.isTireDeflated then
        if factor<1 then
          local node=v.data.nodes[cid]
          if node and not affected[cid] then affected[cid]={node.frictionCoef or 1,node.slidingFrictionCoef or node.frictionCoef or 1} end
          local saved=affected[cid]
          if saved then obj:setNodeFrictionSlidingCoefs(cid,saved[1]*factor,saved[2]*factor) end
        elseif affected[cid] then
          local saved=affected[cid];obj:setNodeFrictionSlidingCoefs(cid,saved[1],saved[2]);affected[cid]=nil
        end
      else affected[cid]=nil end
    end
  end
end
local function updateGFX(dt)
  if dt<=0 then return end
  updatePuddleGrip(dt)
  local power=(electrics.values.ignitionLevel or 0)>0
  model.setMode(state,power and mode or 0)
  model.step(state,dt,rain)
  electrics.values.vr_wiper=state.sweep
  electrics.values.wipers=power and mode/3 or 0
  for _,d in ipairs(drops) do
    local cleared=false
    if state.sweepMax-state.sweepMin>0.00001 then
      for _,angle in ipairs(d.angles) do
        if angle>=0 and model.crossed(state.sweepMin,state.sweepMax,angle) then cleared=true end
      end
    end
    if cleared then d.visible=false;d.age=0
    else model.updateDrop(d,dt,rain,0,0) end
    d.prop.hidden=d.prop.disabled or not d.visible
  end
end
local function getState()
  local count=0;for _,d in ipairs(drops) do if d.visible then count=count+1 end end
  return {mode=mode,rain=rain,phase=state.phase,sweep=state.sweep,drops=#drops,visible=count}
end
M.init=reset;M.reset=reset;M.updateGFX=updateGFX
M.setPuddles=setPuddles;M.setRain=setRain;M.setMode=setMode;M.cycle=cycle;M.getState=getState
return M
