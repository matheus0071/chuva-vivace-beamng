local M={}
local rain,wetness,mode=0,0,2
local originals={}
local originalPrecipitation=nil
local coverage,drops
local puddleObjects,puddles={},{}
local timer=0
local syncAll
local function finite(value)
 value=tonumber(value) or 0
 return value==value and value or 0
end
local function activeMap()
 return getMissionFilename and (getMissionFilename() or '')~=''
end
local function restoreGrip()
 if not core_environment or not be then return end
 for name,saved in pairs(originals) do
  local entry=core_environment.groundModels[name]
  if entry and entry.cdata==saved.data then
   entry.cdata.staticFrictionCoefficient=saved.static
   entry.cdata.slidingFrictionCoefficient=saved.sliding
   be:setGroundModel(name,entry.cdata)
  end
 end
 originals={}
end
local function precipitationObject(name,dataBlock,width,height)
 local o=scenetree.findObject(name)
 if not o then
  o=createObject("Precipitation")
  if not o then return nil end
  o:setField("dataBlock",0,dataBlock)
  o:setField("boxWidth",0,tostring(width))
  o:setField("boxHeight",0,tostring(height))
  o:setPosition(vec3(0,0,20))
  o:registerObject(name)
 end
 return o
end
local function ensurePrecipitation()
 coverage=coverage or precipitationObject("vrRain_coverage","rain_medium",90,35)
 drops=drops or precipitationObject("vrRain_drops","rain_drop",36,20)
 return coverage~=nil and drops~=nil
end
local function setNativeRain(value)
 if not ensurePrecipitation() then return false end
 local rate=math.floor(1200*value)
 coverage.numDrops=rate
 drops.numDrops=math.floor(800*value)
 return true
end
local function restoreRain()
 if coverage then coverage.numDrops=0 end
 if drops then drops.numDrops=0 end
 if originalPrecipitation~=nil and core_environment and core_environment.setPrecipitation then core_environment.setPrecipitation(originalPrecipitation) end
 originalPrecipitation=nil
end
local function followPrecipitation()
 if rain<=0 or not ensurePrecipitation() then return end
 local vehicle=getPlayerVehicle and getPlayerVehicle(0)
 if not vehicle then return end
 local p=vehicle:getPosition()
 coverage:setPosition(p+vec3(0,0,36))
 drops:setPosition(p+vec3(0,0,18))
end
local function placePuddle(index,p)
 local name="vrRainPuddle"..index
 local obj=scenetree.findObject(name)
 if not obj then
  obj=createObject("TSStatic")
  if not obj then return false end
  obj:setField("shapeName",0,"/art/shapes/vrRain/vr_puddle.dae")
  obj:setField("collisionType",0,"None")
  obj:registerObject(name)
 end
 puddleObjects[index]=obj
 obj:setPosition(vec3(p.x,p.y,p.z+0.018))
 obj:setScale(vec3(p.rx,p.ry,1))
 return true
end
local function clearPuddles()
 puddles={}
 for i=1,12 do
  local obj=scenetree.findObject("vrRainPuddle"..i)
  if obj then obj:delete() end
 end
 puddleObjects={}
end
function M.recordAsphaltContact(materialId,x,y,z)
 if rain<=0 or (materialId~=10 and materialId~=11) then return false end
 x,y,z=finite(x),finite(y),finite(z)
 if not castRayStatic or not createObject then return false end
 local start=vec3(x,y,z+1.6)
 local hit=castRayStatic(start,vec3(0,0,-1),3.2)
 if hit>=3.2 then return false end
 z=start.z-hit
 for _,p in ipairs(puddles) do
  local dx,dy=x-p.x,y-p.y
  if dx*dx+dy*dy<7.5 then p.z=z; return true end
 end
 local index=#puddles+1
 if index>12 then
  table.remove(puddles,1)
  local old=scenetree.findObject("vrRainPuddle12"); if old then old:delete() end
  puddleObjects[12]=nil
  for i=1,#puddles do puddleObjects[i]=puddleObjects[i+1];puddleObjects[i+1]=nil end
  index=#puddles+1
 end
 local p={x=x,y=y,z=z,rx=1.05,ry=.58,depth=.012}
 puddles[index]=p
 placePuddle(index,p)
 syncAll()
 return true
end
local function serializePuddles()
 local rows={}
 for _,p in ipairs(puddles) do rows[#rows+1]=string.format("{x=%.4f,y=%.4f,z=%.4f,rx=%.3f,ry=%.3f,depth=%.3f}",p.x,p.y,p.z,p.rx,p.ry,p.depth) end
 return "{"..table.concat(rows,",").."}"
end
local function applyGrip()
 if not core_environment or not be then return end
 for name,entry in pairs(core_environment.groundModels or {}) do
  if (name:find('ASPHALT',1,true) or name:find('CONCRETE',1,true) or name=='COBBLESTONE') and entry.cdata then
   local g=entry.cdata
   if not originals[name] then originals[name]={data=g,static=g.staticFrictionCoefficient,sliding=g.slidingFrictionCoefficient} end
   local saved=originals[name]
   g.staticFrictionCoefficient=saved.static*(1-.28*wetness)
   g.slidingFrictionCoefficient=saved.sliding*(1-.36*wetness)
   be:setGroundModel(name,g)
  end
 end
end
local function rememberRain()
 if originalPrecipitation==nil and core_environment and core_environment.getPrecipitation then originalPrecipitation=core_environment.getPrecipitation() or 0 end
end
function M.syncVehicle(id)
 local o=be and be:getObjectByID(id)
 if not o then return end
 o:queueLuaCommand(string.format('local c=controller.getControllerSafe("vrRain"); if c then c.setRain(%.5f); c.setMode(%d); c.setPuddles(%s) end',rain,mode,serializePuddles()))
end
syncAll=function()
 if not be or not be.getObjectCount then return end
 for i=0,be:getObjectCount()-1 do local o=be:getObject(i);if o then M.syncVehicle(o:getID()) end end
end
function M.setRain(value)
 rain=math.max(0,math.min(1,finite(value)))
 if activeMap() then rememberRain();setNativeRain(rain) end
 if rain==0 then wetness=0;clearPuddles();restoreGrip();restoreRain();syncAll() end
 syncAll()
 return M.getState()
end
function M.toggleRain() return M.setRain(rain>0 and 0 or .85) end
function M.setWipers(value)
 mode=math.max(0,math.min(3,math.floor(finite(value))))
 syncAll()
end
function M.toggleWipers() M.setWipers((mode+1)%4);return mode end
function M.onUpdate(dtReal,dtSim)
 if not activeMap() then return end
 local dt=math.max(0,dtSim or dtReal or 0)
 timer=timer+dt
 if timer<.25 then return end
 timer=0
 if rain>0 then
  wetness=math.min(rain,wetness+dt/35)
  rememberRain();setNativeRain(rain);followPrecipitation();applyGrip()
 end
end
function M.getState() return {rain=rain,wetness=wetness,wiperMode=mode,precipitation=activeMap() and rain>0} end
function M.onClientPreStartMission()
 originals={};originalPrecipitation=nil;wetness=0;coverage=nil;drops=nil;clearPuddles()
end
function M.onClientPostStartMission()
 if rain>0 then rememberRain();setNativeRain(rain) end
 syncAll()
end
function M.onClientEndMission()
 restoreGrip();restoreRain();wetness=0;clearPuddles()
end
function M.onExtensionUnloaded()
 rain=0;wetness=0;clearPuddles();restoreGrip();restoreRain();syncAll()
end
function M.onVehicleSpawned(id) M.syncVehicle(id) end
return M
