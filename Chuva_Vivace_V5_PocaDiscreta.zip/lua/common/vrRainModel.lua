local M = {}
local tau = 2 * math.pi
local periods = {[1]=3.8, [2]=1.5, [3]=0.82}
local function sweep(phase) return 0.5 - 0.5 * math.cos(tau * phase) end
function M.new() return {phase=0, sweep=0, mode=0, sweepMin=0, sweepMax=0} end
function M.setMode(s, value)
  value=tonumber(value) or 0
  if value ~= value then value=0 end
  s.mode=math.max(0, math.min(3, math.floor(value)))
end
function M.crossed(a,b,x) return x >= math.min(a,b)-0.025 and x <= math.max(a,b)+0.025 end
function M.step(s, dt, rain)
  dt=math.max(0,tonumber(dt) or 0)
  local old=s.phase
  local period=periods[s.mode] or periods[2]
  local advance=dt/period
  local nextPhase=old
  if s.mode>0 then
    nextPhase=old+advance
  elseif old>0 then
    nextPhase=math.min(1,old+advance)
  end
  local lo,hi=math.min(sweep(old),sweep(nextPhase)),math.max(sweep(old),sweep(nextPhase))
  if math.floor(old+0.5)<math.floor(nextPhase+0.5) then hi=1 end
  if math.floor(old)<math.floor(nextPhase) then lo=0 end
  s.phase=nextPhase % 1
  if s.phase<1e-10 or 1-s.phase<1e-10 then s.phase=0 end
  s.sweep=sweep(s.phase)
  s.sweepMin,s.sweepMax=lo,hi
  return s
end
function M.updateDrop(d,dt,rain,a,b)
  rain=math.max(0,math.min(1,tonumber(rain) or 0))
  if d.covered and M.crossed(a,b,d.angle) and math.abs(b-a)>0.00001 then
    d.visible=false; d.age=0; return
  end
  if rain==0 then
    d.age=d.age+dt
    if d.age>8 then d.visible=false end
  elseif not d.visible then
    d.age=d.age+dt*rain
    if d.age>=d.threshold then d.visible=true; d.age=0 end
  else
    d.age=0
  end
end
return M
