local M={}
function M.isAsphalt(materialId)
 return materialId==10 or materialId==11
end
function M.grip(pools,x,y,z,speed,rain)
 if rain<=0 then return 1 end
 local factor=1
 for _,p in ipairs(pools or {}) do
  local dx,dy=(x-p.x)/p.rx,(y-p.y)/p.ry
  if dx*dx+dy*dy<=1 and z>=p.z-.12 and z<=p.z+1.1 then
   local velocity=math.max(0,math.min(1,(math.abs(speed)-10)/22))
   local depth=math.max(0,math.min(1,p.depth/.015))
   factor=math.min(factor,1-rain*depth*(.1+.58*velocity*velocity))
  end
 end
 return factor
end
return M
